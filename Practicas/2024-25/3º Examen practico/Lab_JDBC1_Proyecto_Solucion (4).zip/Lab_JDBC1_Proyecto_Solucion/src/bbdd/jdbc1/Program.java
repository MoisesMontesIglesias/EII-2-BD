package bbdd.jdbc1;
import java.sql.*;
import java.util.Scanner;



public class Program {
	
	//ORACLE	
	private static String USERNAME = "";
	private static String PASSWORD = "";
	private static String CONNECTION_STRING = "jdbc:oracle:thin:@156.35.94.98:1521:DESA19";
	

	
	public static void main(String[] args) {		
		try {
			exercise1_1();
			//exercise1_2();
			//exercise2();
			//exercise3();
			//exercise4();
			//exercise5_1();
			//exercise5_2();
			//exercise5_3();
			//exercise6_1();
			//exercise6_2();
			//exercise7_1();
			//exercise7_2();
			//exercise8();
		} catch (SQLException e) {			
			System.err.println("SQL Exception " + e.getMessage());
			e.printStackTrace();
		}
	}
	
	/*
		1.	Crear un m�todo en Java que muestre por pantalla los resultados de las consultas 19 y 31 de la Practica SQL2.
		1.1. (19) Obtener el nombre y el apellido de los clientes que han adquirido un coche en un concesionario de Madrid, el cual dispone de coches del modelo gti.
	*/
	public static void exercise1_1() throws SQLException{
		System.out.println("################### EXERCISE 1-1 ###################");
		Connection con = getConnection();	
		
		StringBuilder query = new StringBuilder();
		query.append("SELECT nombre, apellido ");
		query.append(" FROM clientes "); 
		query.append(" WHERE dni IN (SELECT DISTINCT  V.dni ");
		query.append(" FROM ventas V, coches CH, concesionarios CO, distribucion D ");
		query.append(" WHERE V.cifc=CO.cifc AND CO.ciudadc='madrid' AND CO.cifc=D.cifc ");
		query.append(" AND D.codcoche = CH.codcoche AND CH.modelo='gti')");
			
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery(query.toString());
		
		while (rs.next()) {
			System.out.println("Cliente: "+rs.getString("nombre")+" "+rs.getString("apellido"));
		}
		
		rs.close();
		st.close();
		con.close();
	}
	
	/* 
		1.2. (31) Obtener un listado de los concesionarios cuyo promedio de coches supera al promedio de coches de cada uno del resto de concesionarios
		
	*/
	public static void exercise1_2() throws SQLException{
		System.out.println("################### EXERCISE 1-2 ###################");
		Connection con = getConnection();	
		
		StringBuilder query = new StringBuilder();
		query.append("SELECT c.cifc, nombrec, ciudadc ");
		query.append(" FROM concesionarios c, distribucion d ");
		query.append(" WHERE c.cifc=d.cifc ");
		query.append(" GROUP BY c.cifc, nombrec, ciudadc ");
		query.append(" HAVING AVG(cantidad)>= ALL(SELECT AVG(cantidad) FROM distribucion GROUP BY cifc) ");
	
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery(query.toString());		
		while (rs.next()) {
			System.out.println("Concesionario: "+rs.getString("cifc")+" "+rs.getString("nombrec")+" "+rs.getString("ciudadc"));
		}
		rs.close();
		st.close();
		con.close();
	}

	/*
		2. Crear un m�todo en Java que muestre por pantalla el resultado de la consulta 6 de la Practica SQL2 de forma el color de la b�squeda sea introducido por el usuario.
			(6) Obtener el nombre de las marcas de las que se han vendido coches de un color introducido por el usuario.
	*/
	public static void exercise2() throws SQLException{
		System.out.println("################### EXERCISE 2 ###################");
		Connection con = getConnection();		
		
		StringBuilder query = new StringBuilder();
		query.append("SELECT DISTINCT M.nombrem ");
		query.append(" FROM marcas M, marco R, ventas V ");
		query.append(" WHERE M.cifm=R.cifm AND R.codcoche=V.codcoche AND V.color=?");
		PreparedStatement pst = con.prepareStatement(query.toString());

		System.out.println("Por favor, introduzca el color: ");			
		String color = ReadString();
		
		pst.setString(1, color);
		ResultSet rs = pst.executeQuery();		
		while (rs.next()) {
			System.out.println("Marca: "+rs.getString("nombrem"));
		}
		
		rs.close();
		pst.close();
		con.close();
	}
	
	/*
		3.	Crear un m�todo en Java para ejecutar la consulta 25 de la Practica SQL2 de forma que los limites de la cantidad de coches sean introducidos por el usuario.
			(25) Obtener el cifc de los concesionarios que disponen de una cantidad de coches comprendida entre dos cantidades introducidas por el usuario, ambas inclusive.
	*/
	public static void exercise3() throws SQLException{
		System.out.println("################### EXERCISE 3 ###################");
		Connection con = getConnection();		
		
		StringBuilder query = new StringBuilder();
		query.append("SELECT cifc, sum(cantidad) Total ");
		query.append(" FROM distribucion ");
		query.append(" GROUP BY cifc ");
		query.append(" HAVING sum(cantidad) BETWEEN ? AND ?");
		PreparedStatement pst = con.prepareStatement(query.toString());	

		System.out.println("Por favor, introduzca la cantidad minima: ");	
		int minimum = ReadInt();
		System.out.println("Por favor, introduzca la cantidad maxima: ");	
		int maximun = ReadInt();	
		
		pst.setInt(1, minimum);
		pst.setInt(2, maximun);
		ResultSet rs = pst.executeQuery();		
		while (rs.next()) {
			System.out.println("Concesionario: "+rs.getString("cifc")+" Stock:  "+rs.getInt("total"));
		}
		rs.close();
		pst.close();
		con.close();
	}
	
	/*
		4.	Crear un m�todo en Java para ejecutar la consulta 22 de la Practica SQL2 de forma que tanto la ciudad del concesionario como el color sean introducidos por el usuario.
			(22) Obtener los nombres de los clientes que no han comprado coches de un color introducido por el usuario en concesionarios de una ciudad introducida por el usuario.

	*/
	public static void exercise4() throws SQLException{
		System.out.println("################### EXERCISE 4 ###################");
		Connection con = getConnection();	
		
		StringBuilder query = new StringBuilder();		
		query.append("SELECT DISTINCT CL.nombre ");
		query.append(" FROM clientes CL, ventas V ");
		query.append(" WHERE V.dni=CL.dni AND CL.dni NOT IN (SELECT V.dni ");
		query.append("  FROM concesionarios CO, ventas V ");
		query.append("  WHERE CO.cifc=V.cifc AND CO.ciudadc=? AND V.color=? )");
	
		PreparedStatement pst = con.prepareStatement(query.toString());	

		System.out.println("Por favor, introduzca la ciudad: ");	
		String city = ReadString();
		System.out.println("Por favor, introduzca el color: ");	
		String color = ReadString();	
		
		pst.setString(1, city);
		pst.setString(2, color);
		ResultSet rs = pst.executeQuery();		
		while (rs.next()) {
			System.out.println("Cliente: "+rs.getString("nombre"));
		}	
		
		rs.close();
		pst.close();
		con.close();
	}
	
	/*
		5.	Crear un m�todo en Java que haciendo uso de la instrucci�n SQL adecuada:
		5.1. Introduzca datos en la tabla coches cuyos datos son introducidos por el usuario.

	*/
	public static void exercise5_1() throws SQLException{
		System.out.println("################### EXERCISE 5-1 ###################");
		Connection con = getConnection();
		
		StringBuilder query = new StringBuilder();
		query.append("INSERT INTO coches (codcoche,nombrech,modelo) VALUES (?,?,?)");		
		PreparedStatement pst = con.prepareStatement(query.toString());	

		System.out.println("Por favor, introduzca el codigo del coche: ");	
		int codcoche = ReadInt();
		System.out.println("Por favor, introduzca el nombre del coche: ");	
		String nombrech = ReadString();
		System.out.println("Por favor, introduzca el modelo del coche: ");	
		String modelo = ReadString();	
		
		pst.setInt(1, codcoche);
		pst.setString(2, nombrech);
		pst.setString(3, modelo);
		if(pst.executeUpdate() == 1)
			System.out.println("Datos insertados correctamente.");
		else
			System.out.println("Ha ocurrido un error, datos no insertados.");	
		
		pst.close();
		con.close();
	}
	
	/*
		5.2. Borre un determinado coche cuyo c�digo es introducido por el usuario.
	*/
	public static void exercise5_2() throws SQLException{
		System.out.println("################### EXERCISE 5-2 ###################");
		Connection con = getConnection();	
		
		StringBuilder query = new StringBuilder();
		query.append("DELETE FROM coches WHERE codcoche=?");		
		PreparedStatement pst = con.prepareStatement(query.toString());	

		System.out.println("Por favor, introduzca el codigo del coche:");	
		int codcoche = ReadInt();
		
		pst.setInt(1, codcoche);
		if(pst.executeUpdate() == 1)
			System.out.println("Datos borrados correctamente.");
		else
			System.out.println("Ha ocurrido un error, datos no borrados.");	
		
		pst.close();
		con.close();
	}
	
	/*	 
		5.3. Actualice el nombre y el modelo para un determinado coche cuyo c�digo es introducido por el usuario.
	*/
	public static void exercise5_3() throws SQLException{		
		System.out.println("################### EXERCISE 5-3 ###################");
		Connection con = getConnection();		
		
		StringBuilder query = new StringBuilder();
		query.append("UPDATE coches SET nombrech=?, modelo=? WHERE CODCOCHE=?");		
		PreparedStatement pst = con.prepareStatement(query.toString());

		System.out.println("Por favor, introduzca el codigo del coche: ");	
		int codcoche = ReadInt();
		System.out.println("Por favor, introduzca el nombre del coche: ");	
		String nombrech = ReadString();
		System.out.println("Por favor, introduzca el modelo del coche: ");	
		String modelo = ReadString();
		
		pst.setString(1, nombrech);
		pst.setString(2, modelo);
		pst.setInt(3, codcoche);
		if(pst.executeUpdate() == 1)
			System.out.println("Datos actualizados correctamente.");
		else
			System.out.println("Ha ocurrido un error, datos no actualizados.");			
		
		pst.close();
		con.close();		
	}
	
	/*
		6.  Invocar desde Java una funci�n y un procedimiento (ya definidos en la base de datos) que, dado un c�digo de concesionario, devuelven el n�mero de ventas que se han realizado en el mismo.
		6.1. Funci�n (Oracle)
	*/
	public static void exercise6_1() throws SQLException{
		System.out.println("################### EXERCISE 6-1 (ORACLE) ###################");
		Connection con = getConnection();		
		
		StringBuilder query = new StringBuilder();
		query.append("{? = call FUNCTION10(?)}");
		
		System.out.println("Por favor, introduzca el codigo del concesionario:");	
		String cifc = ReadString();
		
        CallableStatement cst = con.prepareCall(query.toString());
        cst.registerOutParameter(1, Types.INTEGER);
		cst.setString(2,cifc);
    
		cst.execute();
		System.out.println("Ventas: " + cst.getInt(1));
		
		cst.close();
		con.close();		
	}

	/*	
		6.2. Procedimiento
	*/
	public static void exercise6_2() throws SQLException{		
		System.out.println("################### EXERCISE 6-2 ###################");
		Connection con = getConnection();		
		
		StringBuilder query = new StringBuilder();
		query.append("{call PROCEDURE10(?,?)}");	
		
		System.out.println("Por favor, introduzca el codigo del concesionario:");	
		String cifc = ReadString();
		
        CallableStatement cst = con.prepareCall(query.toString());
		cst.setString(1, cifc);
		cst.registerOutParameter(2,Types.INTEGER);
        
		cst.execute();
		System.out.println("Ventas: " + cst.getInt(2));
		
		cst.close();
		con.close();		
	}
	
	/*
		7.  Invocar desde Java una funci�n y un procedimiento (ya definidos en la base de datos) que,  dado un dni que es pasado como par�metro devuelve 2 valores: 
		a) el n�mero de coches que se ha comprado dicho cliente y b) el n�mero de concesionarios en los que lo ha hecho. 
		7.1. Funci�n (Oracle)
	*/
	public static void exercise7_1() throws SQLException{		
		
		System.out.println("################### EXERCISE 7-1 (Oracle) ###################");
		Connection con = getConnection();		
		
		StringBuilder query = new StringBuilder();
		query.append("{? = call FUNCTION11(?,?)}");
        
        System.out.println("Por favor, introduzca el dni: ");
        String dni = ReadString();
        
		CallableStatement cst = con.prepareCall(query.toString());
		cst.registerOutParameter(1,Types.INTEGER);
		cst.registerOutParameter(3,Types.INTEGER);
		cst.setString(2,dni);
        
		cst.execute();
		System.out.println("El cliente: " +dni+" ha comprado "+ cst.getInt(1)+" en "+ cst.getInt(3)+" concesionarios");
		
		cst.close();
		con.close();		
	}	
	
    
	/*
		7.2. Procedimiento
	*/
	public static void exercise7_2() throws SQLException{		
		System.out.println("################### EXERCISE 7-2 ###################");
		Connection con = getConnection();		
		
		StringBuilder query = new StringBuilder();
		query.append("{call PROCEDURE11(?,?,?)}");		
		
		System.out.println("Por favor, introduzca el dni: ");	
		String dni = ReadString();
		
        CallableStatement cst = con.prepareCall(query.toString());
		cst.setString(1, dni);
		cst.registerOutParameter(2,Types.INTEGER);
        cst.registerOutParameter(3,Types.INTEGER);
        
		
		cst.execute();		
		System.out.println("El cliente: " +dni+" ha comprado "+ cst.getInt(2)+" en "+ cst.getInt(3)+" concesionarios");
		
		
		cst.close();
		con.close();			
	}

	/*
 		8.  Crear un m�todo en Java que imprima por pantalla los coches que han sido adquiridos por cada cliente.
            Adem�s, deber� imprimirse para cada cliente el n�mero de coches que ha comprado y el n�mero de
 		concesionarios en los que ha comprado. Aquellos clientes que no han adquirido ning�n coche no
		deben aparecer en el listado.
	*/
	public static void exercise8() throws SQLException {	
		System.out.println("################### EXERCISE 8 ###################");
		Connection con = getConnection();
		
		StringBuilder queryclientes = new StringBuilder();
		queryclientes.append("SELECT DISTINCT c.dni, nombre, apellido");
		queryclientes.append(" FROM clientes c, ventas v");
		queryclientes.append(" WHERE c.dni=v.dni");
		Statement st=con.createStatement();
		ResultSet rsclientes=st.executeQuery(queryclientes.toString());
		
		StringBuilder querycount = new StringBuilder();
		querycount.append("SELECT COUNT(*) as nch, COUNT(DISTINCT cifc) as nco");
		querycount.append(" FROM VENTAS WHERE dni=?");
		PreparedStatement pstcount = con.prepareStatement(querycount.toString());
		
		StringBuilder querycoches = new StringBuilder();
		querycoches.append("SELECT CH.codcoche as codch, CH.nombrech as nomch, CH.modelo as mod, V.color as col");
		querycoches.append(" FROM coches CH, ventas V ");
		querycoches.append(" WHERE CH.codcoche=V.codcoche  AND V.dni=?");
		
		PreparedStatement pstcoches = con.prepareStatement(querycoches.toString());
		
		while(rsclientes.next()){
		    			
			pstcount.setString(1, rsclientes.getString("dni"));
			ResultSet rs=pstcount.executeQuery();
			rs.next();
			
			System.out.println("- Cliente: "+rsclientes.getString("nombre")+" "+rsclientes.getString("apellido")+" "+rs.getInt("nch")+" "+rs.getInt("nco"));
								
			pstcoches.setString(1, rsclientes.getString("dni"));
			rs = pstcoches.executeQuery();		
			
			while(rs.next()){
			  System.out.println("---> Coche: "+rs.getInt("codch")+" "+rs.getString("nomch")+" "+rs.getString("mod")+" "+rs.getString("col"));
			}
			rs.close();
		}
		
		pstcount.close();
		pstcoches.close();
		rsclientes.close();	
		st.close();
		con.close();
	} 
	
	
	// ------------------- DATABASE UTILS -------------------
	private static Connection getConnection() throws SQLException{
		if(DriverManager.getDriver(CONNECTION_STRING) == null)
				DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
		return  DriverManager.getConnection(CONNECTION_STRING,USERNAME,PASSWORD);
	}
	
	
	
	
	@SuppressWarnings("resource")
	private static String ReadString(){
		return new Scanner(System.in).nextLine();		
	}
	
	@SuppressWarnings("resource")
	private static int ReadInt(){
		return new Scanner(System.in).nextInt();			
	}
	
}
