package es.uniovi.eii.bbdd.jdbc.exam.june22;
import java.util.Scanner;

/**
 * From this main class it must be possible to execute
 * the methods implemented during the test.
 * 
 * (ES)
 * Si al importar el proyecto te da un problema con la
 * versión de Java: Botón secundario sobre el
 * proyecto > "Build Path", "Configure Build Path" > "Libraries".
 * En "Modulepath" elimina la versión de JRE que te está
 * dando problemas y añade la que tengas en tu equipo
 * desde el botón de "Add Library".
 * 
 * (EN)
 * If when importing the project you have a problem with
 * the Java version: Right-click on the
 * project > "Build Path", "Configure Build Path" > "Libraries".
 * In "Modulepath" delete the JRE version that is giving you
 * problems and add the one you have in your computer from
 * the "Add Library" button.
 *  
 * @author Databases 2022 Teaching Staff.
 */
public class Program {
	
	public static void main(String[] args) {
		
	}

	@SuppressWarnings({ "resource", "unused" })
	private static String ReadString(){
		return new Scanner(System.in).nextLine();		
	}
	
	@SuppressWarnings({ "resource", "unused" })
	private static int ReadInt(){
		return new Scanner(System.in).nextInt();			
	}	
}
