package bbdd.jdbc1;
import java.sql.*;
import java.util.Scanner;

public class Program {
		
	public static void main(String[] args) {
		//Ejemplos para leer por teclado
				//System.out.println("Leer un entero por teclado");	
				//int entero = ReadInt();
				//System.out.println("Leer una cadena por teclado");	
				//String cadena = ReadString();
				try {
					//exercise1_1();
					//exercise1_2();
					//exercise2();
					//exercise3();
					//exercise4();
					//exercise5_1();
					//exercise5_2();
					//exercise5_3();
					//exercise6_1();
					//exercise6_2();
					//exercise7_1();
					//exercise7_2();
					//exercise8();
					//ExamenEj2();
					//ej1();
					//ej2();
					//ej3();
					//ej4();
					//ej5();
					//ej6();
					//ej7();
					//ej8();
					//ej1Exam1();
					ej2Exam1();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}	
	}
	
	private static String USERNAME = "UO296102"; //"alumno"
	private static String PASSWORD =  "Romanon04"; //"alumno"
	private static String CONNECTION_STRING = "jdbc:oracle:thin:@156.35.94.98:1521:DESA19";

	private static Connection getConnection() throws SQLException {
		//Le indicamos a Java que vamos a utilizar la base de datos oracle
		DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
		//Nos aseguramos que el proyecto est� importada, click derecho en el proyecto --> properties --> Java Build Path --> Libraries --> importar en ClassPath el jdbc
		
		//Crear una conexi�n con la base datos Oracle --> Todas las excepciones son SQLException
		return DriverManager.getConnection(CONNECTION_STRING, USERNAME,PASSWORD);
	}
	
	public static void exercise0() throws SQLException {
		
		Connection con = getConnection();
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("   ");
		
		while (rs.next()) {
			System.out.println("Cliente: ");
			
		}
		rs.close();
		st.close();
		con.close(); 
	}
	
	/*
		1.	Crear un m�todo en Java que muestre por pantalla los resultados de las consultas 19 y 31 de la Pr�ctica SQL2. 
		1.1. (19) Obtener el nombre y el apellido de los clientes que han adquirido un coche en un concesionario de Madrid, el cual dispone de coches del modelo gti.
	 */
	public static void exercise1_1() throws SQLException{
		Connection con = getConnection();
		Statement st = con.createStatement();
		ResultSet rs= st.executeQuery("select distinct c.nombre, c.apellido\r\n"
				+ "from clientes c, ventas v, concesionarios co, distribucion d, coches ch\r\n"
				+ "where c.dni=v.dni and v.cifc=co.cifc and co.ciudadc='madrid' and co.cifc=d.cifc\r\n"
				+ "and d.codcoche=ch.codcoche and ch.modelo='gti'");
		while (rs.next()) {
			String nombre = rs.getString(1);
			String apellido = rs.getString(2);
//			String nombre = rs.getString("nombre");
//			String apellido = rs.getString("apellido");
			System.out.println("Nombre: " + nombre + " Apellido: " + apellido);
		}
		rs.close();
		st.close();
		con.close();
	}
	
	/* 
		1.2. (31) Obtener un listado de los concesionarios cuyo promedio de coches supera a la cantidad promedio de todos los concesionarios. 
	*/
	public static void exercise1_2() throws SQLException{
		Connection con = getConnection();
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("select co.cifc, co.nombrec, co.ciudadc\r\n"
				+ "from distribucion d, concesionarios co\r\n"
				+ "where d.cifc=co.cifc\r\n"
				+ "group by co.cifc, co.nombrec, co.ciudadc\r\n"
				+ "having avg(d.cantidad) >= all(select avg(d.cantidad) from distribucion d group by d.cifc)");
		while(rs.next()) {
			int cifc = rs.getInt(1);
			String nombre = rs.getString(2);
			String ciudad = rs.getString(3);
//			int cifc = rs.getInt("cifc");
//			String nombre = rs.getString("nombrec");
//			String ciudad = rs.getString("ciudadc");
			System.out.println("Cifc: " + cifc + " nombre: " + nombre + " ciudad: " + ciudad);
		}
		rs.close();
		st.close();
		con.close();
	}
	
	/*
		2. Crear un m�todo en Java que muestre por pantalla el resultado de la consulta 6 de la Pr�ctica SQL2 de forma el color de la b�squeda sea introducido por el usuario.
			(6) Obtener el nombre de las marcas de las que se han vendido coches de un color introducido por el usuario.
	*/
	public static void exercise2() throws SQLException{
		Connection con = getConnection();
		PreparedStatement ps = con.prepareStatement("select m.nombrem\r\n"
				+ "from marcas m, marco ma, ventas v\r\n"
				+ "where m.cifm=ma.cifm and ma.codcoche=v.codcoche and v.color=?");
		System.out.println("Introduce un color a la consulta: ");
		String color = ReadString();
		ps.setString(1, color);
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			String nombre = rs.getString(1);
			//String nombre = rs.getString("nombrem");
			System.out.println("El nombre de la marca con el color: " + color + " es: " + nombre);
		}
		rs.close();
		ps.close();
		con.close();
	}
	
	/*
		3.	Crear un m�todo en Java para ejecutar la consulta 25 de la Pr�ctica SQL2 de forma que los limites la cantidad de coches sean introducidos por el usuario. 
			(25) Obtener el cifc de los concesionarios que disponen de una cantidad de coches comprendida entre dos cantidades introducidas por el usuario, ambas inclusive.

	*/
	public static void exercise3() throws SQLException{
		Connection con = getConnection();
		PreparedStatement ps = con.prepareStatement("select distinct d.cifc, sum(d.cantidad)\r\n"
				+ "from distribucion d\r\n"
				+ "group by d.cifc\r\n"
				+ "having sum(d.cantidad) >= ? and sum(d.cantidad) <= ?");
		System.out.println("Da un valor m�nimo: ");
		int minimo = ReadInt();
		ps.setInt(1, minimo);
		System.out.println("Da un valor m�ximo: ");
		int maximo = ReadInt();
		ps.setInt(2, maximo);
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			int cifc = rs.getInt(1);
			int cantidad = rs.getInt(2);
			System.out.println("El cifc es: " + cifc + " y la cantidad es: " + cantidad);
		}
		rs.close();
		ps.close();
		con.close();
	}
	
	/*
		4.	Crear un m�todo en Java para ejecutar la consulta 22 de la Pr�ctica SQL2 de forma que tanto la ciudad del concesionario como el color sean introducidos por el usuario. 
			(22) Obtener los nombres de los clientes que no han comprado coches de un color introducido por el usuario en concesionarios de una ciudad introducida por el usuario.

	*/
	public static void exercise4() throws SQLException{
		Connection con = getConnection();
		PreparedStatement ps = con.prepareStatement("select nombre\r\n"
				+ "from clientes c\r\n"
				+ "where c.dni not in (select v.dni \r\n"
				+ "                    from ventas v, concesionarios c\r\n"
				+ "                    where v.cifc=c.cifc and c.ciudadc = ? and v.color = ?)");
		System.out.println("Introduce la ciudad: ");
		String ciudad = ReadString();
		ps.setString(1, ciudad);
		System.out.println("Introduce el color: ");
		String color = ReadString();
		ps.setString(2, color);
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			String nombre = rs.getString(1);
			System.out.println("El nombre es: " + nombre);
		}
		rs.close();
		ps.close();
		con.close();
	}
	
	/*
		5.	Crear un m�todo en Java que haciendo uso de la instrucci�n SQL adecuada: 
		5.1. Introduzca datos en la tabla coches cuyos datos son introducidos por el usuario.

	*/
	public static void exercise5_1() throws SQLException{
		Connection con = getConnection();
		PreparedStatement ps = con.prepareStatement("insert into coches(codcoche, nombrech, modelo) values (?,?,?)");
		System.out.println("Introduce un codigo de coche: ");
		String codcoche = ReadString();
		ps.setString(1, codcoche);
		System.out.println("Introduce nombre de coche: ");
		String nombreCoche = ReadString();
		ps.setString(2, nombreCoche);
		System.out.println("Introduce modelo de coche");
		String modeloCoche = ReadString();
		ps.setString(3, modeloCoche);
		if(ps.executeUpdate() == 1) {
			System.out.println("A�adido correctamente");
		} else {
			System.out.println("No se ha podido a�adir");
		}
		ps.close();
		con.close();
	}
	
	/*
		5.2. Borre un determinado coche cuyo c�digo es introducido por el usuario. 
	*/
	public static void exercise5_2() throws SQLException{
		Connection con = getConnection();
		PreparedStatement ps = con.prepareStatement("delete from coches where codcoche = ?");
		System.out.println("Inserta el codigo de coche a eliminar");
		String codcoche = ReadString();
		ps.setString(1, codcoche);
		if(ps.executeUpdate() == 1) {
			System.out.println("Se elimino correctamente");
		} else {
			System.out.println("No se pudo eliminar");
		}
		ps.close();
		con.close();
	}
	
	/*	 
		5.3. Actualice el nombre y el modelo para un determinado coche cuyo c�digo es introducido por el usuario.
	*/
	public static void exercise5_3() throws SQLException{		
		Connection con = getConnection();
		PreparedStatement ps = con.prepareStatement("update coches set nombrech=?, modelo=? where codcoche=?");
		System.out.println("Introduce el nuevo nombre del coche: ");
		String nombrech = ReadString();
		ps.setString(1, nombrech);
		System.out.println("Introduce el nuevo modelo del coche: ");
		String modelo = ReadString();
		ps.setString(2, modelo);
		System.out.println("Introduce el codigo del coche que queremos cambiar: ");
		String codcoche = ReadString();
		ps.setString(3, codcoche);
		if(ps.executeUpdate() == 1) {
			System.out.println("Se realizaron los cambios correctamente");
		} else {
			System.out.println("No se han podido realizar los cambios");
		}
		ps.close();
		con.close();
	}
	
	/*
		6. Invocar la funci�n y el procedimiento del ejercicio 10 de la Pr�ctica PL1 desde una aplicacion Java. 
			(10) Realizar un procedimiento y una funci�n que dado un c�digo de concesionario devuelve el n�mero ventas que se han realizado en el mismo.
		6.1. Funci�n
	*/
	public static void exercise6_1() throws SQLException{		
		Connection con = getConnection();
		CallableStatement cs = con.prepareCall("? = call PRAC1_F10(?)");
		System.out.println("Da un codigo de cifc: ");
		String pcifc = ReadString();
		cs.setString(2, pcifc);
		cs.registerOutParameter(1, java.sql.Types.INTEGER);
		cs.execute();
		int n = cs.getInt(1);
		System.out.println("El valor devuelto es: " + n);
		cs.close();
		con.close();
	}
	
	/*	
		6.2. Procedimiento
	*/
	public static void exercise6_2() throws SQLException{		
		Connection con = getConnection();
		CallableStatement cs = con.prepareCall("{call P1_CASA_11(?,?,?)}");
		System.out.println("Dame un dni: ");
		String dni = ReadString();
		cs.setString(1, dni);
		cs.registerOutParameter(2, java.sql.Types.VARCHAR);
		cs.registerOutParameter(3, java.sql.Types.VARCHAR);
		cs.execute();
		String ncoches = cs.getString(2);
		String nconcesionarios = cs.getString(3);
		System.out.println("El ncoches es: " + ncoches + " y el nconcesionarios es: " + nconcesionarios);
		cs.close();
		con.close();
	}
	
	/*
		7. Invocar la funci�n y el procedimiento del ejercicio 11 de la Pr�ctica PL1 desde una aplicacion Java. 
			(11) Realizar un procedimiento y una funci�n que dado un dni que es pasado como par�metro devuelva 2  valores: 
			a) el n�mero de coches que se ha comprado dicho cliente y b) el n�mero de concesionarios en los que lo ha hecho.
		7.1. Funci�n

	*/
	public static void exercise7_1() throws SQLException{		
		Connection con = getConnection();
		CallableStatement cs = con.prepareCall("{? = call P1_CASA_F11(?,?)}");
		System.out.println("Dame el dni: ");
		String dni = ReadString();
		cs.setString(2, dni);
		
		cs.registerOutParameter(1, java.sql.Types.INTEGER);
		cs.registerOutParameter(3, java.sql.Types.INTEGER);
		
		cs.execute();
		int n = cs.getInt(1);
		int s = cs.getInt(3);
		System.out.println("El cliente: " + dni + " devuelto es: " + n + " y el numero de concesionarios es: " + s);
		cs.close();
		con.close();
	}	
	
	/*
		7.2. Procedimiento
	*/
	public static void exercise7_2() throws SQLException{		
		Connection con = getConnection();
		CallableStatement cs = con.prepareCall("{call P1_CASA_11(?,?,?)}");
		
		System.out.println("Dame el valor del dni: ");
		String pdni = ReadString();
		cs.setString(1, pdni);
		cs.registerOutParameter(2, java.sql.Types.INTEGER);
		cs.registerOutParameter(3, java.sql.Types.INTEGER);
		
		cs.execute();
		
		int a = cs.getInt(2);
		int b = cs.getInt(3);
		System.out.println("Con el dni: " + pdni + " el numero de coches es: " + a + " el numero de concesionarios es: " + b);
		
		cs.close();
		con.close();
	}
	
    /*
     	8. Crear un m�todo en Java que imprima por pantalla los coches que han sido adquiridos por cada cliente.
     	Adem�s, deber� imprimirse para cada cliente el n�mero de coches que ha comprado y el n�mero de
     	concesionarios en los que ha comprado. Aquellos clientes que no han adquirido ning�n coche no
		deben aparecer en el listado.
    */
	public static void exercise8() throws SQLException{		
		Connection con = getConnection();
		Statement st = con.createStatement();
		ResultSet rsCliente = st.executeQuery("select cl.nombre, cl.apellido, count(v.codcoche), count(v.cifc), cl.dni\r\n"
				+ "from clientes cl, ventas v\r\n"
				+ "where cl.dni = v.dni\r\n"
				+ "group by cl.nombre, cl.apellido, cl.dni");
		PreparedStatement ps = con.prepareStatement("select c.codcoche, c.nombrech, c.modelo, v.color\r\n"
				+ "from coches c, ventas v\r\n"
				+ "where c.codcoche=v.codcoche and v.dni = ?");
		while(rsCliente.next()) {
			String nombre = rsCliente.getString(1);
			String apellido = rsCliente.getString(2);
			int codcoche = rsCliente.getInt(3);
			int cifc = rsCliente.getInt(4);
			System.out.println("- Cliente: " + nombre + " " + apellido + " " + codcoche + " " + cifc);
			String dni = rsCliente.getString(5);
			ps.setString(1, dni);
			ResultSet rsCoches = ps.executeQuery();
			while (rsCoches.next()) {
				String ccodCoche = rsCoches.getString(1);
				String nombrec = rsCoches.getString(2);
				String modelo = rsCoches.getString(3);
				String ccifc = rsCoches.getString(4);
				System.out.println("	---> Coche: " + ccodCoche + " " + nombrec + " " + modelo + " " + ccifc);
			}
			rsCoches.close();
		}
		ps.close();
		rsCliente.close();
		st.close();
		con.close();
	}
	
	public static void ExamenEj2() throws SQLException {
		Connection con = getConnection();
		Statement st = con.createStatement();
		ResultSet rsInstructor = st.executeQuery("select i.instructor_id, i.instructor_name, count(p.project_id) as num_projects, sum(p.extra_payment) as total_extra_payment\r\n"
				+ "from instructor i, participates p, project pr\r\n"
				+ "where p.instructor_id=p.instructor_id and pr.project_id = p.project_id and pr_duration > 1\r\n"
				+ "and p.instructor_id not in (select s.student_id from student s where s.instructor_id = i.instructor_id)\r\n"
				+ "group by i.instructor_id, i.instructor_name\r\n"
				+ "order by i.instructor_name desc, num_projects desc ");
		
		PreparedStatement ps = con.prepareStatement("select distinct d.dept_name, d.dept_building, c.course_id, c.title, s.sec_id, s.semester, s.year\r\n"
				+ "from instructor i, department d, course c, teaches t, is_prerequisite ip, section s\r\n"
				+ "where t.instructor_id=i.instructor_id and t.course_id=s.course_id and t.semester=s.semester\r\n"
				+ "and t.year=s.year and c.course_id=s.course_id and ip.prereq_id=c.course_id and c.dept_name=d.dept_name\r\n"
				+ "and t.instructor_id = ?\r\n"
				+ "order by course_id desc ");
		while (rsInstructor.next()) {
			String instructor_id = rsInstructor.getString(1);
			String name = rsInstructor.getString(2);
			int num_projects = rsInstructor.getInt(3);
			float total_extra_payment = rsInstructor.getFloat(4);
			System.out.println("INSTRUCTOR: " + instructor_id + " / " + name + " / " + num_projects + " / " + total_extra_payment);
			
			ps.setString(1, instructor_id);
			ResultSet rsSection = ps.executeQuery();
			while (rsSection.next()) {
				String dept_name = rsSection.getString(1);
				String dept_building = rsSection.getString(2);
				String course_id = rsSection.getString(3);
				String title = rsSection.getString(4);
				String sec_id = rsSection.getString(5);
				String semester = rsSection.getString(6);
				String year = rsSection.getString(7);
				System.out.println("--SECTION: " + dept_name + " - " + dept_building + " - " + course_id + " - " + title + " - " + sec_id + " - " + semester + " - " + year);
			}
			rsSection.close();
		}
		rsInstructor.close();
		ps.close();
		st.close();
		con.close();
	}
	
	public static void ej1() throws SQLException{
		Connection con = getConnection();
		CallableStatement cs = con.prepareCall("{call PROCEDURE1(?,?,?,?)}");
		System.out.println("Dame el nombre del departamento: ");
		String nombre = ReadString();
		cs.setString(1, nombre);
		cs.registerOutParameter(2, java.sql.Types.VARCHAR);
		cs.registerOutParameter(3, java.sql.Types.VARCHAR);
		cs.registerOutParameter(4, java.sql.Types.INTEGER);
		cs.execute();
		String a = cs.getString(2);
		String b = cs.getString(3);
		int c = cs.getInt(4);
		System.out.println("El nombre del estudiante es: " + a + ", su id del curso es: " + b + ", y el numero de cursos es: " + c);
		cs.close();
		con.close();
	}

	public static void ej2() throws SQLException{
		Connection con = getConnection();
		CallableStatement cs = con.prepareCall("{? = call FUNCTION2(?)}");
		System.out.println("Dame un id de editor: ");
		String id = ReadString();
		cs.registerOutParameter(1, java.sql.Types.VARCHAR);
		cs.setString(2, id);
		cs.execute();
		String a = cs.getString(1);
		System.out.println("La salida de la funci�n es: " + a);
		cs.close();
		con.close();
	}
	
	public static void ej3() throws SQLException{
		Connection con = getConnection();
		CallableStatement cs = con.prepareCall("{? = call P3_CASA_8(?)}");
		System.out.println("Dame un id de titulo: ");
		String id = ReadString();
		cs.registerOutParameter(1, java.sql.Types.FLOAT);
		cs.setString(2, id);
		cs.execute();
		float a = cs.getFloat(1);
		System.out.println("El valor es: " + a);
		cs.close();
		con.close();
	}
	
	public static void ej4() throws SQLException{
		Connection con = getConnection();
		CallableStatement cs = con.prepareCall("{? = call PRAC1_FPROFE(?,?)}");
		System.out.println("Dame un de dni: ");
		String dni = ReadString();
		cs.registerOutParameter(1, java.sql.Types.NUMERIC);
		cs.setString(2, dni);
		cs.registerOutParameter(3, java.sql.Types.NUMERIC);
		cs.execute();
		int a = cs.getInt(1);
		int b = cs.getInt(3);
		System.out.println("El dni es: " + dni + ", su numero de concesionarios es: " + b + " y su numero de coches es: " + a);
		cs.close();
		con.close();
	}
	
	public static void ej5() throws SQLException{
		Connection con = getConnection();
		CallableStatement cs = con.prepareCall("{? = call PRAC1_F10(?)}");
		cs.registerOutParameter(1, java.sql.Types.INTEGER);
		System.out.println("Dame un concesionario: ");
		String conc = ReadString();
		cs.setString(2, conc);
		cs.execute();
		int a = cs.getInt(1);
		System.out.println("EL numero de ventas es: " + a);
		cs.close();
		con.close();
	}
	
	public static void ej6() throws SQLException{
		Connection con = getConnection();
		CallableStatement cs = con.prepareCall("{call PROCEDURE3(?)}");
		System.out.println("Dame un nombre: ");
		String nombre = ReadString();
		cs.setString(1, nombre);
		cs.execute();
		cs.close();
		con.close();
	}
	
	public static void ej7() throws SQLException{
		Connection con = getConnection();
		CallableStatement cs = con.prepareCall("{call PROCEDURE7()}");
		System.out.println("Se aplico" + cs.execute());
		cs.close();
		con.close();
	}
	
	public static void ej8() throws SQLException{
		Connection con = getConnection();
		CallableStatement cs = con.prepareCall("{? = call INFO_SPONSOR(?,?)}");
		System.out.println("Dame el nombre del ciclista: ");
		String nombre = ReadString();
		cs.registerOutParameter(1, java.sql.Types.INTEGER);
		cs.setString(2, nombre);
		cs.registerOutParameter(3, java.sql.Types.VARCHAR);
		cs.execute();
		int a = cs.getInt(1);
		String b = cs.getString(3);
		System.out.println("El ciclista: " + nombre + " tiene una cantidad de: " + a + " cuyo nombre de equipo es: " + b);
		cs.close();
		con.close();
	}
	
	public static void ej1Exam1() throws SQLException{
		Connection con = getConnection();
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("select i.instructor_id, i.salary, d.dept_budget/(sum(t.num_hours)*count(s.student_id)) as new_salary_instructor\r\n"
				+ "from instructor i, department d, student s, teaches t\r\n"
				+ "where i.dept_name=d.dept_name and s.instructor_id=i.instructor_id and t.instructor_id=i.instructor_id\r\n"
				+ "group by i.instructor_id, d.dept_budget, i.salary");
		while(rs.next()) {
			String id = rs.getString(1);
			float old_salary = rs.getFloat(2);
			float new_salary = rs.getFloat(3);
			System.out.println("El instructor con id: " + id + " tiene un salario actual de: " + old_salary);
			PreparedStatement ps = con.prepareStatement("update instructor SET salary=? where instructor_id = ?");
			ps.setString(2, id);
			ps.setFloat(1, new_salary);
			ps.execute();
			System.out.println("El instructor con id: " + id + " tiene un salario nuevo de: " + new_salary);
			ps.close();
		}
		rs.close();
		st.close();
		con.close();
	}
	
	public static void ej2Exam1() throws SQLException{
		Connection con = getConnection();
		PreparedStatement ps = con.prepareStatement("select distinct c.course_id, c.title, c.type, d.dept_building\r\n"
				+ "from course c, department d, is_prerequisite ip\r\n"
				+ "where c.dept_name=d.dept_name and c.course_id=ip.course_id and d.dept_name = ? and ip.prereq_id > 2\r\n"
				+ "order by c.course_id desc, c.title desc");
		System.out.println("Introduce el nombre del departamento: ");
		String nombre = ReadString();
		ps.setString(1, nombre);
		
		PreparedStatement psSection = con.prepareStatement("select distinct s.sec_id, s.year, c.class_building, instructor_name\r\n"
				+ "from section s, classroom c, teaches t, instructor i\r\n"
				+ "where s.sec_id=t.sec_id and s.semester=t.semester and s.year=t.year and\r\n"
				+ "s.class_building=c.class_building and s.room_number=c.room_number and \r\n"
				+ "t.instructor_id=i.instructor_id and s.semester='Spring' and \r\n"
				+ "i.instructor_name like 'S%' and s.course_id=?\r\n"
				+ "order by sec_id asc");
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			String course_id = rs.getString(1);
			String title = rs.getString(2);
			String type = rs.getString(3);
			String dept_building = rs.getString(4);
			System.out.println("COURSE: " + course_id + " -- " + title + " -- " + type + " -- " + dept_building);
			psSection.setString(1, course_id);
			ResultSet rsSection = psSection.executeQuery();
			while(rsSection.next()) {
				String sec_id = rsSection.getString(1);
				String year = rsSection.getString(2);
				String class_building = rsSection.getString(3);
				String instructor_name = rsSection.getString(4);
				System.out.println("   --> SECTION: " + sec_id + " -- " + year + " -- " + class_building + " -- " + instructor_name);
			}
			rsSection.close();
		}
		rs.close();
		psSection.close();
		ps.close();
		con.close();
	}
	
	@SuppressWarnings("resource")
	private static String ReadString(){
		return new Scanner(System.in).nextLine();		
	}
	
	@SuppressWarnings("resource")
	private static int ReadInt(){
		return new Scanner(System.in).nextInt();			
	}	
}
