package bbdd.testJDBC;
import java.util.Scanner;
import java.sql.*;

import org.hsqldb.types.Types;

public class Program {
	
	public static void main(String[] args) {		
		try {
			exercise1();
			exercise2();
			exercise3();
		} catch (SQLException e) {			
			System.err.println("SQL Exception " + e.getMessage());
			e.printStackTrace();
		}
	}
	
	public static void exercise1(){		
		System.out.println("################### EXERCISE 1 ###################");		
	}
	
	public static void exercise2() {		
		System.out.println("################### EXERCISE 2 ###################");		
	}

	public static void exercise3() {		
		System.out.println("################### EXERCISE 3 ###################");		
		
	}
	

    // ------------------- DATABASE UTILS -------------------
	
	@SuppressWarnings("resource")
	private static String ReadString(){
		return new Scanner(System.in).nextLine();		
	}
	
	@SuppressWarnings("resource")
	private static int ReadInt(){
		return new Scanner(System.in).nextInt();			
	}

    @SuppressWarnings("resource")
	private static Double ReadDouble(){
		return new Scanner(System.in).nextDouble();			
	}	
}
