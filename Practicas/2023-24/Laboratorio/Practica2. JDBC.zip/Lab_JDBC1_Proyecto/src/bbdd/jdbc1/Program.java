package bbdd.jdbc1;
import java.util.Scanner;
import java.sql.*;

public class Program {
	
	public static void main(String[] args) {
		//Ejemplos para leer por teclado
		//System.out.println("Leer un entero por teclado");	
		//int entero = ReadInt();
		//System.out.println("Leer una cadena por teclado");	
		//String cadena = ReadString();
		try {
			//exercise0();
			//exercise1_1();
			//exercise2();
			//exercise3();
			//exercise5_1();
			//exercise6_1();
			//exercise8();
			Examen1();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static String USERNAME = "alumno";//"UO296102"; //"alumno"
	private static String PASSWORD =  "alumno";//"Romanon04"; //"alumno"
	private static String CONNECTION_STRING = "jdbc:oracle:thin:@156.35.94.98:1521:DESA19";
	
	private static Connection getConnection() throws SQLException {
		//Le indicamos a Java que vamos a utilizar la base de datos oracle
		DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
		//Nos aseguramos que el proyecto est� importada, click derecho en el proyecto --> properties --> Java Build Path --> Libraries --> importar en ClassPath el jdbc
		
		//Crear una conexi�n con la base datos Oracle --> Todas las excepciones son SQLException
		return DriverManager.getConnection(CONNECTION_STRING, USERNAME,PASSWORD);
	}
	
	 public static void exercise0() throws SQLException {
			
			Connection con = getConnection();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("   ");
			
			while (rs.next()) {
				System.out.println("Cliente: ");
				
			}
			rs.close();
			st.close();
			con.close();
			
		   
	}
	
	/*
		1.	Crear un metodo en Java que muestre por pantalla los resultados de las consultas 21 y 32 de la Practica SQL2. 
		1.1. (21) Obtener el nombre y el apellido de los clientes que han adquirido un coche en un concesionario de Madrid, el cual dispone de coches del modelo gti.
	 */
	public static void exercise1_1() throws SQLException {
		//Primer paso, tener la conexi�n abierta --> throws SQLException
		Connection con = getConnection();
		//Creamos el enunciado/sentencia
		Statement st = con.createStatement();
		// Ejecutamos la consulta
		ResultSet rs = st.executeQuery("SELECT nombre, apellido "
				+ "FROM clientes\r\n"
				+ "WHERE dni IN (SELECT DISTINCT V.dni\r\n"
				+ "    FROM ventas V, coches CH, concesionarios CO, distribucion D\r\n"
				+ "    WHERE V.cifc=CO.cifc AND CO.ciudadc='madrid' AND CO.cifc=D.cifc\r\n"
				+ "        AND D.codcoche = CH.codcoche AND CH.modelo='gti')");
		//Recorremos el resultado
		while(rs.next()) {
			String nombre = rs.getString("nombre");
			String apellido = rs.getString("apellido");
			System.out.println("Cliente: " + nombre + " " + apellido);
		}
		//Cerramos las consultas abiertas
		rs.close();
		rs.close();
		con.close();
	}
	
	/* 
		1.2. (32) Obtener un listado de los concesionarios cuyo promedio de coches supera a la cantidad promedio de todos los concesionarios. 
	*/
	public static void exercise1_2() {
		
	}
	
	/*
		2. Crear un metodo en Java que muestre por pantalla el resultado de la consulta 6 de la Practica SQL2 de forma el color de la busqueda sea introducido por el usuario.
			(6) Obtener el nombre de las marcas de las que se han vendido coches de un color introducido por el usuario.
	*/
	public static void exercise2() throws SQLException {
		Connection con = getConnection();
		//1. Pre-compilamos o preparamos la consulta con el par�metro
		PreparedStatement ps = con.prepareStatement("select distinct m.nombrem "
				+ "from marcas m, marco r, ventas v\r\n"
				+ "where m.cifm = r.cifm and r.codcoche = v.codcoche and v.color = ?");
		
		//Solicitar el valor del parametro: en este caso el color
		System.out.println("Por favor, introduzca el color: ");
		String color = ReadString();
		
		//Damos valor al par�metro seg�n color introducido por el usuario
		ps.setString(1, color);
		
		//Ejecutamos la consulta
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			System.out.println("Marca: " + rs.getString("nombrem"));
		}
		rs.close();
		ps.close();
		con.close();
	}
	
	/*
		3.	Crear un metodo en Java para ejecutar la consulta 27 de la Practica SQL2 de forma que los limites la cantidad de coches sean introducidos por el usuario. 
			(27) Obtener el cifc de los concesionarios que disponen de una cantidad de coches comprendida entre dos cantidades introducidas por el usuario, ambas inclusive.

	*/
	public static void exercise3() throws SQLException {
		Connection con = getConnection();
		PreparedStatement ps = con.prepareStatement("SELECT cifc, sum(cantidad) AS total\r\n"
				+ "FROM distribucion\r\n"
				+ "GROUP BY cifc\r\n"
				+ "HAVING sum(cantidad)>=? AND sum(cantidad)<=?");
		
		System.out.println("Introduce el l�mite inferior: ");
		int inferior = ReadInt();
		System.out.println("Introduce el l�mite superior: ");
		int superior = ReadInt();
		
		ps.setInt(1, inferior);
		ps.setInt(2, superior);
		
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			System.out.println("Edad: " + rs.getInt("cifc") + " " + rs.getInt("total"));
		}
		rs.close();
		ps.close();
		con.close();
	}
	
	/*
		4.	Crear un metodo en Java para ejecutar la consulta 24 de la Practica SQL2 de forma que tanto la ciudad del concesionario como el color sean introducidos por el usuario. 
			(24) Obtener los nombres de los clientes que no han comprado coches de un color introducido por el usuario en concesionarios de una ciudad introducida por el usuario.

	*/
	public static void exercise4() {
		
	}
	
	/*
		5.	Crear un metodo en Java que haciendo uso de la instruccion SQL adecuada: 
		5.1. Introduzca datos en la tabla coches cuyos datos son introducidos por el usuario.

	*/
	public static void exercise5_1() throws SQLException {
		Connection con = getConnection();
		PreparedStatement ps = con.prepareStatement("insert into coches (codcoche, nombrech, modelo) values (?,?,?)");
		// Pedir valores de los par�metros y pasarlos a la consulta
		System.out.println("Introduzca codcche:");	
		String pcodcoche = ReadString();
		System.out.println("Introduzca nombrech: ");	
		String pnombrech = ReadString();
		System.out.println("Introduzca modelo: ");	
		String pmodelo = ReadString();
		ps.setString(1,pcodcoche);
		ps.setString(2, pnombrech);
		ps.setString(3, pmodelo);
		int regInsertados = ps.executeUpdate(); // Devuelve el n�mero de filas insertadas
		System.out.println("N�mero de filas insertadas: " + regInsertados);
		ps.close();
		con.close();
		
	}
	
	/*
		5.2. Borre un determinado coche cuyo codigo es introducido por el usuario. 
	*/
	public static void exercise5_2() {
		
	}
	
	/*	 
		5.3. Actualice el nombre y el modelo para un determinado coche cuyo codigo es introducido por el usuario.
	*/
	public static void exercise5_3() {		
		
	}
	
	/*
		6. Invocar la funcion y el procedimiento del ejercicio 10 de la practica PL1 desde una aplicacion Java. 
			(10) Realizar un procedimiento y una funcion que dado un codigo de concesionario devuelve el numero ventas que se han realizado en el mismo.
		6.1. Funcion
	*/
	public static void exercise6_1() throws SQLException {		
		Connection con = getConnection();
		CallableStatement cs = con.prepareCall("{?=call FUNCTION10 (?)}");
		System.out.println("Introduzca cifc: ");
		String pcifc = ReadString();
		cs.setString(1, pcifc);
		cs.registerOutParameter(1, java.sql.Types.INTEGER);
		cs.execute();
		int nventas = cs.getInt(1);
		System.out.println("El numero de ventas es: " + nventas);
		cs.close();
		con.close();
	}
	
	/*	
		6.2. Procedimiento
	*/
	public static void exercise6_2() {		
			
	}
	
	/*
		7. Invocar la funcion y el procedimiento del ejercicio 11 de la Practica PL1 desde una aplicacion Java. 
			(11) Realizar un procedimiento y una funcion que dada una ciudad que se le pasa como parametro devuelve el numero de clientes de dicha ciudad.
		7.1. Funcion

	*/
	public static void exercise7_1() {		
			
	}	
	
	/*
		7.2. Procedimiento
	*/
	public static void exercise7_2() {		
				
	}
	
    /*
     	8. Crear un metodo en Java que imprima por pantalla los coches que han sido adquiridos por cada cliente.
     	Ademas, debera imprimirse para cada cliente el numero de coches que ha comprado y el numero de
     	concesionarios en los que ha comprado. Aquellos clientes que no han adquirido ningun coche no
		deben aparecer en el listado.
    */
	public static void exercise8() throws SQLException {		
		Connection con = getConnection();
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("select clientes.dni, count(distinct cifc) nconces, count(*) nventas\r\n"
				+ "from clientes,ventas\r\n"
				+ "where clientes.dni = ventas.dni\r\n"
				+ "group by clientes.dni, nombre, apellido");
		PreparedStatement ps = con.prepareStatement("select ventas.codcoche, nombrech, modelo, color\r\n"
				+ "				+ \"from ventas,coches\r\n"
				+ "				+ \"where ventas.codcoche = coches.codcoche and dni='?'");
		PreparedStatement ps2 = con.prepareStatement("Select count(*) from ventas where color = ?");
		while(rs.next()) {
			System.out.println("Cliente: " + rs.getString("nombre")  + " " + rs.getString("apellido") + " " + rs.getString("nconces"));
			String pdni = rs.getString("dni");
			//asignamos valor al par�metro
			ps.setString(1, pdni);
			ResultSet rsCoches = ps.executeQuery();
			while(rsCoches.next()) {
				String pcolor = rsCoches.getString("color");
				ps2.setString(1, pcolor);
				ResultSet rsColor = ps2.executeQuery();
				// en este caso, esta consulta como solo devuelve un color no hace falta while, pero puede dar problemas
				rsColor.next(); 
				// recuperamos el numero de coches de ese color
				int nCochesColor = rsColor.getInt("ncochesColor");
				System.out.println("--> Coches: " + rsCoches.getString("codcoche") + " " + rsCoches.getString("nombrech") + " " + rsCoches.getString("modelo") + " " + pcolor + 
						" Totales vendidos de este color: " + nCochesColor);

				rsColor.close();
			}
			
			rsCoches.close();
		}
		ps.close();
		rs.close();
		st.close();
		con.close();
		
	}
	
	/*
	Ejercicio Examen
	*/
	public static void Examen1() throws SQLException {		
		Connection con = getConnection();
		Statement st = con.createStatement();
		PreparedStatement ps = con.prepareStatement("SELECT c.codcine, sum(precio) recaudacion_cine\r\n"
				+ "FROM cines c, salas s, entradas e\r\n"
				+ "WHERE c.codcine=s.codcine AND s.codsala=e.codsala AND c.localidad=?\r\n"
				+ "GROUP BY c.codcine");
		//Pedimos valor del parametro
		System.out.println("Introduzca la localidad: ");
		String plocalidad = ReadString();
		//Asignamos valor al par�metro
		ps.setString(1, plocalidad);
		//Ejecutamos la consulta
		ResultSet rs = ps.executeQuery();	
		while (rs.next()) {
			System.out.println("Cine: " + rs.getInt("codcine") + " " + "Precio: " + rs.getDouble("recaudacion_cine"));
		}
		rs.close();
		ps.close();
		con.close();
	}
	
	public static void Examen2() throws SQLException {		
		Connection con = getConnection();
		Statement st = con.createStatement();
		PreparedStatement ps = con.prepareStatement("SELECT p.codpelicula, p.titulo, sum(precio) recaudacion_peli\r\n"
				+ "         FROM peliculas p, entradas e, salas s\r\n"
				+ "         WHERE p.codpelicula=e.codpelicula AND e.codsala=s.codsala AND\r\n"
				+ "s.codcine=?\r\n"
				+ "         GROUP BY p.codpelicula, p.titulo");
		//Pedimos valor del parametro
		System.out.println("Introduzca el c�digo del cine: ");
		String pcodigo = ReadString();
		//Asignamos valor al par�metro
		ps.setString(1, pcodigo);
		//Ejecutamos la consulta
		ResultSet rs = ps.executeQuery();	
		while (rs.next()) {
			System.out.println("Pelicula: " + rs.getInt("codpelicula") + " " + "Titulo: " + rs.getString("p.titulo") + " " + 
		"Precio: " + rs.getDouble("recaudacion_peli"));
		}
		rs.close();
		ps.close();
		con.close();
	}
		
	@SuppressWarnings("resource")
	private static String ReadString(){
		return new Scanner(System.in).nextLine();		
	}
	
	@SuppressWarnings("resource")
	private static int ReadInt(){
		return new Scanner(System.in).nextInt();			
	}	
}
